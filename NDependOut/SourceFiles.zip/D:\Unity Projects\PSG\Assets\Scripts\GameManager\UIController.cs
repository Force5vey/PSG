using UnityEngine;

public class UIController : MonoBehaviour
{

    public Color textColorSelected;
    public Color textColorEnabled;
    public Color textColorPressed;
    public Color textColorDisabled;

}
