

public interface ILevelSpecific
{

    void CustomStart();
}
